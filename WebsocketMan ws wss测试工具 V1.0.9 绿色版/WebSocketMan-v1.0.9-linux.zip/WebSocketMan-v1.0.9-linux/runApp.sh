#!/bin/bash
work_dir=$(cd $(dirname $0);pwd -P)
cd $work_dir
export LD_LIBRARY_PATH=${work_dir}/lib:$LD_LIBRARY_PATH
export QT_PLUGIN_PATH=${work_dir}/plugins:$QT_PLUGIN_PATH
cd bin/
./WebSocketMan
